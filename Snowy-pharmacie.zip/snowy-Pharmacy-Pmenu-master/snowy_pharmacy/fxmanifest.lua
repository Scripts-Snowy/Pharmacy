fx_version 'adamant'

game 'gta5'

client_scripts {
	'dependencies/menu.lua',
	'cl_snowyParmacy.lua'
}

server_scripts {
      'sv_snowyParmacy.lua'
}

# Snowy-Pharmacy-Pmenu
Snowy Pharmacy Pmenu P-menu

--Merci de pas changer le nom pour mettre le votre et dire a tout le monde que c'est vous qui avais crée le script


-------------------------------------------------------------------------- FR -----------------------------------------------------------------------------------------------

--En cas de probleme ou d'erreur :



--Mon discord Perso : Snowy#3468

-------------------------------------------------------------------------- ENG ---------------------------------------------------------------------------------------------

